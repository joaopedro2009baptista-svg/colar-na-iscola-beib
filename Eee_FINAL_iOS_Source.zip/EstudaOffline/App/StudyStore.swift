import Foundation
import SwiftUI

@MainActor
final class StudyStore: ObservableObject {
    @Published var recognizedText = ""
    @Published var answers: [QuestionAnswer] = []
    @Published var logs: [QuestionLog] = []
    @Published var essayTopic = ""
    @Published var essayInstructions = ""
    @Published var essayDraft = ""
    @Published var chatMessages: [ChatMessage] = []
    @Published var isWorking = false
    @Published var statusMessage: String?

    private let persistenceURL: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        return base.appendingPathComponent("study-logs.json")
    }()

    init() { loadLogs() }

    func addLog(_ log: QuestionLog) {
        logs.insert(log, at: 0)
        saveLogs()
    }

    func clearQuestionSession() {
        recognizedText = ""
        answers = []
        statusMessage = nil
    }

    private func loadLogs() {
        guard let data = try? Data(contentsOf: persistenceURL),
              let saved = try? JSONDecoder().decode([QuestionLog].self, from: data) else { return }
        logs = saved
    }

    private func saveLogs() {
        guard let data = try? JSONEncoder().encode(logs) else { return }
        try? data.write(to: persistenceURL, options: .atomic)
    }
}
