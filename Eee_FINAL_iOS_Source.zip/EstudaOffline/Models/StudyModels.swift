import Foundation

enum ConfidenceBand {
    case low, medium, high

    init(percent: Int) {
        if percent < 50 { self = .low }
        else if percent < 70 { self = .medium }
        else { self = .high }
    }

    var label: String {
        switch self {
        case .low: "Baixa"
        case .medium: "Média"
        case .high: "Alta"
        }
    }
}

struct QuestionAnswer: Identifiable, Codable {
    var id = UUID()
    var number: Int
    var option: String?
    var confidencePercent: Int
    var status: String
    var initialInterpretation: String
    var recognizedQuestion: String
    var rationale: String
}

struct QuestionLog: Identifiable, Codable {
    var id = UUID()
    var questionNumber: Int
    var initialInterpretation: String
    var revisedInterpretation: String
    var proposedAnswer: String?
    var confidencePercent: Int
    var reason: String
    var timestamp = Date()
}

struct ChatMessage: Identifiable {
    var id = UUID()
    var isUser: Bool
    var text: String
}

struct ParsedQuestion: Codable {
    var number: Int
    var question: String
    var options: [String: String]
}

struct AIQuestionResult: Codable {
    var number: Int
    var option: String
    var confidence: Int
    var status: String
    var interpretedQuestion: String
    var rationale: String
    var uncertainty: String
}
