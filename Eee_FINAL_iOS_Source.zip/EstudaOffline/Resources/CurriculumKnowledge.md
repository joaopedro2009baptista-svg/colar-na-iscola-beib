# Base curricular do Estuda Offline

Esta base é material de apoio local para recuperação aumentada por contexto (RAG). Ela não substitui livros, aulas, legislação educacional ou o enunciado original. O tutor deve recuperar apenas os trechos relevantes, comparar unidades e condições do problema e declarar quando faltarem dados.

## Português e Literatura

### Parnasianismo
O Parnasianismo valoriza forma, métrica, rima, vocabulário preciso, descrição plástica, impessoalidade relativa e trabalho artesanal do poema. No Brasil, os nomes mais associados são Olavo Bilac, Raimundo Correia e Alberto de Oliveira. Em uma questão, procure marcas como soneto, regularidade formal, culto da forma, objetividade descritiva e arte pela arte. Não conclua apenas pela presença de linguagem culta: observe o conjunto de características.

### Simbolismo
O Simbolismo privilegia sugestão, musicalidade, subjetividade, espiritualidade, mistério, sinestesia, imagens vagas e símbolos. No Brasil, destacam-se Cruz e Sousa e Alphonsus de Guimaraens. Sinestesia mistura sensações de sentidos diferentes, como cor sonora ou perfume doce. Contraste útil: a precisão formal e a descrição plástica parnasianas não equivalem à sugestão musical e ao estado de alma simbolistas.

### Interpretação e gramática
Antes de escolher uma alternativa, identifique tema, tese, finalidade, interlocutor, marcas de ironia, pressupostos e relação entre partes do texto. Diferencie informação explícita de inferência autorizada. Em gramática, examine concordância, regência, crase, colocação pronominal, pontuação, coesão referencial e valor dos conectivos. A pontuação não deve ser julgada apenas por pausa da fala: ela depende da estrutura sintática.

### Exemplo orientador
Se o texto usa imagens sensoriais misturadas, aliterações, espiritualidade e indeterminação, a hipótese simbolista é mais forte. Se organiza versos regulares, descrição objetiva e acabamento formal, a hipótese parnasiana é mais forte. A resposta deve citar a evidência textual decisiva.

## Inglês

### Comparatives
Para comparar dois elementos, use adjetivo curto + `-er` + `than` em padrões como `taller than`; com adjetivos longos, use `more ... than`, como `more interesting than`. Para igualdade, use `as ... as`; para desigualdade, `not as ... as`. Não use `more` com a forma padrão em `-er`.

### Superlatives
Para indicar o grau máximo em um grupo, use `the` + adjetivo curto em `-est`, como `the tallest`, ou `the most` + adjetivo longo, como `the most interesting`. Formas irregulares: `good/better/the best`, `bad/worse/the worst`, `far/farther or further/the farthest or furthest`, `little/less/the least`, `many or much/more/the most`.

### Ortografia e interpretação
Em `big`, dobra-se a consoante final: `bigger`, `biggest`. Em adjetivos terminados em consoante + `y`, troca-se `y` por `i`: `happy`, `happier`, `happiest`. A interpretação depende de tempo verbal, pronomes, conectivos, falso cognato e referência. `Actually` significa “na verdade”, não “atualmente”.

### Exemplo orientador
Na frase “This exercise is ___ than the previous one”, a presença de `than` pede comparativo. Na frase “It is ___ book in the library”, o grupo e o artigo normalmente pedem superlativo. O contexto pode exigir uma forma irregular.

## Matemática I

### Sistemas lineares
Um sistema linear reúne equações com as mesmas incógnitas. Em duas variáveis, duas retas podem ser concorrentes, coincidentes ou paralelas. Solução única ocorre quando as retas se cruzam; infinitas soluções, quando representam a mesma reta; nenhuma solução, quando são paralelas distintas.

### Métodos e determinante
Use substituição quando uma variável estiver isolada; eliminação quando os coeficientes permitirem cancelar uma variável; escalonamento para sistemas maiores. Para `a1x+b1y=c1` e `a2x+b2y=c2`, `D=a1b2-a2b1`; se `D ≠ 0`, há solução única. Depois de resolver, substitua os valores nas equações originais.

### Modelagem e erros comuns
Traduza cuidadosamente unidades e palavras como “ao todo”, “diferença”, “a mais” e “proporcional”. Não troque coeficiente por termo independente. Um resultado numérico sem verificação não basta quando as alternativas podem conter arredondamentos ou sinais invertidos.

### Exemplo orientador
Para `x+y=10` e `2x-y=5`, a soma das equações elimina `y` e fornece `3x=15`, logo `x=5` e `y=5`. A conferência deve recuperar 10 e 5 nas duas equações.

## Matemática II

### Seções e planificações
Seção é a figura obtida pelo corte de um sólido por um plano. A forma depende da orientação do plano. Planificação representa a superfície de um sólido aberta em um plano sem sobreposição; verifique se as faces realmente fecham o sólido.

### Cilindro
Volume: `V=πr²h`. Área lateral: `Al=2πrh`. Área total: `At=2πr²+2πrh`. O raio é a distância do centro à borda; diâmetro é `2r`. Mantenha unidades quadradas em áreas e cúbicas em volumes.

### Cone e tronco de cone
Cone reto: `V=πr²h/3`; geratriz `g=√(r²+h²)`; área lateral `Al=πrg`; área total `At=πr²+πrg`. Tronco de cone: `V=πh(R²+Rr+r²)/3` e área lateral `Al=π(R+r)g`. Não use a altura como geratriz sem verificar o triângulo retângulo.

### Exemplo orientador
Se um cilindro tem raio 2 cm e altura 5 cm, o volume é `20π cm³`. Se a questão pedir área externa com bases, some as duas bases à área lateral. Antes de calcular, identifique se foi dado raio ou diâmetro.

## Química

### Gases e variáveis
Pressão, volume, temperatura e quantidade de matéria se relacionam pela equação dos gases ideais `PV=nRT`. Temperatura absoluta deve estar em kelvin: `K=°C+273,15`. A constante `R` precisa ser compatível com as unidades de pressão e volume.

### Leis dos gases
Boyle: com `T` e `n` constantes, `P1V1=P2V2`. Charles: com `P` e `n` constantes, `V1/T1=V2/T2`. Gay-Lussac: com `V` e `n` constantes, `P1/T1=P2/T2`. Lei combinada: `P1V1/T1=P2V2/T2` para quantidade fixa de gás.

### Misturas e interpretação
A pressão total de uma mistura ideal é a soma das pressões parciais: `Ptotal=ΣPi`. A fração molar é `Xi=ni/ntotal` e, em condições ideais, `Pi=XiPtotal`. Gases reais se afastam do modelo ideal principalmente em alta pressão e baixa temperatura.

### Erros comuns
Não use graus Celsius diretamente em relações que envolvem temperatura absoluta. Confira se a quantidade de matéria permanece constante. Converta litros e metros cúbicos quando necessário: `1 m³=1000 L`.

## Física

### Óptica geométrica
A luz se propaga em linha reta em meios homogêneos e transparentes no modelo geométrico. Na reflexão, o ângulo de incidência é igual ao de reflexão, ambos medidos em relação à normal. Não meça o ângulo em relação à superfície.

### Refração
Índice de refração: `n=c/v`. Lei de Snell: `n1 sen(θ1)=n2 sen(θ2)`. Ao entrar em meio de maior índice, o raio se aproxima da normal; ao entrar em meio de menor índice, afasta-se. Frequência não muda na passagem de meio, mas velocidade e comprimento de onda mudam.

### Espelhos esféricos
Para espelho esférico paraxial, `f=R/2`. Equação de Gauss: `1/f=1/p+1/p'`. Aumento linear: `A=i/o=-p'/p` em uma convenção cartesiana comum. Espelho côncavo pode produzir imagem real ou virtual; convexo, para objeto real, produz imagem virtual, direita e reduzida.

### Lentes
Lente convergente tem foco positivo na convenção usual e pode formar imagem real ou virtual. Lente divergente tem foco negativo e, para objeto real, forma imagem virtual, direita e reduzida. Use a convenção de sinais adotada no enunciado; não misture diagramas com fórmulas de convenções diferentes.

### Exemplo orientador
Se `f=10 cm` e `p=30 cm`, então `1/p'=1/10-1/30=1/15`, logo `p'=15 cm`. O sinal e a natureza da imagem ainda devem ser interpretados segundo a convenção usada.

## Biologia

### Grupos vegetais
Briófitas são avasculares, pequenas, têm gametófito dominante e dependem de água para a fecundação. Pteridófitas são vasculares, não têm sementes, têm esporófito dominante e ainda dependem de água para a fecundação. Gimnospermas possuem sementes não envolvidas por fruto e pólen, reduzindo a dependência de água. Angiospermas possuem flores, frutos e sementes protegidas; ocorre dupla fecundação.

### Histologia vegetal
Meristemas produzem crescimento. Epiderme protege. Parênquima realiza fotossíntese ou reserva. Colênquima sustenta órgãos jovens com flexibilidade. Esclerênquima sustenta com células geralmente lignificadas. Xilema conduz água e sais minerais; floema conduz açúcares e outros fotoassimilados entre fontes e drenos.

### Fisiologia vegetal
Fotossíntese converte energia luminosa em energia química, usando água e dióxido de carbono e liberando oxigênio na formulação escolar usual. Estômatos regulam trocas gasosas e transpiração. A transpiração contribui para o fluxo no xilema por coesão-tensão. Auxinas, giberelinas, citocininas, etileno e ácido abscísico participam de crescimento, amadurecimento e respostas ao ambiente.

## História

### Primeira República brasileira
O período vai de 1889 a 1930. A República da Espada inclui os governos de Deodoro e Floriano. A Constituição de 1891 estabeleceu federalismo, presidencialismo e Estado laico. A República Oligárquica foi marcada por poder regional, coronelismo, voto aberto, fraudes e política dos governadores.

### Conflitos e sociedade
Canudos expressou conflitos sociais, religiosos e fundiários no sertão. A Revolta da Vacina relacionou reformas urbanas autoritárias, vacinação obrigatória e resistência popular. A Revolta da Chibata criticou castigos físicos e condições na Marinha. Contestado, greves operárias e tenentismo revelam tensões sociais e políticas diferentes.

### Economia e crise
Café, exportação, dependência de crédito e poder das elites agrárias estruturaram parte da economia. “Café com leite” é uma simplificação didática da predominância de elites de São Paulo e Minas e não uma alternância perfeitamente mecânica. A crise de 1929 e conflitos eleitorais contribuíram para a Revolução de 1930.

## Geografia

### Dinâmica populacional
Indicadores básicos incluem natalidade, mortalidade, fecundidade, expectativa de vida, mortalidade infantil, crescimento vegetativo e saldo migratório. Crescimento natural é natalidade menos mortalidade; crescimento total também considera migração. Não confunda taxa, número absoluto e proporção.

### Transição demográfica
O modelo didático descreve a passagem de altas taxas de natalidade e mortalidade para quedas sucessivas, seguida por envelhecimento. A velocidade e a forma variam entre países e regiões. Pirâmides etárias permitem observar base, corpo e topo da estrutura populacional.

### População brasileira
O Brasil passou por urbanização intensa, redução da fecundidade e envelhecimento. A distribuição populacional é desigual e se relaciona à história econômica, urbanização, infraestrutura, clima, relevo e oportunidades. Migrações internas podem ser pendulares, sazonais, temporárias ou permanentes; fatores de expulsão e atração atuam juntos.

## Filosofia

### Maquiavel
Maquiavel analisa a política pela realidade efetiva e pela manutenção do Estado. Em `O Príncipe`, `virtù` é capacidade de agir politicamente diante das circunstâncias e `fortuna` é contingência. A imagem pública, a força, as leis e a estabilidade devem ser contextualizadas. Não reduza sua obra à frase “os fins justificam os meios”, que não é uma citação literal simples.

### Estado moderno
O Estado moderno envolve território, soberania, centralização administrativa, burocracia e monopólio progressivo do uso legítimo da força. A formação foi histórica e desigual. Compare Estado, governo, nação e sociedade civil: governo é administração temporária; Estado é a estrutura política duradoura; nação envolve pertencimento histórico-cultural.

## Sociologia

### Mídia e comunicação
Meios de comunicação podem informar, socializar, criar agendas, reforçar estereótipos, influenciar consumo e disputar interpretações. Analise propriedade, seleção de pautas, enquadramento, publicidade, algoritmos, concentração e desigualdade de acesso. Público não é necessariamente passivo: repertórios e contextos alteram a recepção.

### Cultura de massa
Cultura de massa é produzida e distribuída para públicos amplos em sistemas industriais e midiáticos. A análise pode destacar padronização, mercantilização, repetição e alcance, sem concluir que toda cultura popular seja inferior ou que todos os indivíduos respondam do mesmo modo.

### Homem-massa
A expressão aparece em críticas à massificação e ao conformismo e precisa ser atribuída ao autor e ao contexto da questão. Não trate “massa” como sinônimo automático de povo ou de baixa renda. Diferencie comportamento coletivo, opinião pública, indústria cultural e participação política.

## Redação dissertativo-argumentativa

### Estrutura
A introdução contextualiza e apresenta uma tese. Cada desenvolvimento deve conter argumento, explicação, evidência ou repertório verificável e vínculo explícito com a tese. A conclusão retoma o problema e encaminha solução ou síntese coerente. O texto deve responder ao tema exato, não a um assunto apenas parecido.

### Proposta de intervenção
Em modelo ENEM, uma proposta completa costuma explicitar agente, ação, meio ou modo, finalidade ou efeito e detalhamento, respeitando direitos humanos. Não invente estatísticas, leis, pesquisas ou citações. Repertório deve ser pertinente e produtivo, não apenas decorativo.

### Revisão
Revise tese, progressão argumentativa, repetição vocabular, conectivos, concordância, regência, pontuação, pronomes e conclusão. Evite frases prontas, generalizações absolutas e conectivos mecânicos. O tutor deve preservar a voz do estudante e apontar alterações sem prometer burlar detectores de IA.

## Estratégia de recuperação

Para responder, identifique disciplina, tópico, grandeza ou conceito central, recupere os trechos mais relacionados e depois confira o enunciado. Em cálculos, escreva as variáveis, unidades, fórmula e substituição. Em interpretação, cite a evidência. Em alternativas, elimine afirmações incompatíveis antes de escolher. Se a foto ou o contexto não trouxer informação essencial, marque a questão como inconclusiva.

## Fontes de referência para atualização

A base deve ser complementada somente com materiais cuja licença permita uso e redistribuição. Referências institucionais úteis incluem a [Base Nacional Comum Curricular do MEC](http://basenacionalcomum.mec.gov.br/), o [Portal do IBGE Educa](https://educa.ibge.gov.br/), o [INEP](https://www.gov.br/inep/pt-br) e materiais didáticos licenciados pela escola. O app deve registrar a origem e a licença de cada arquivo importado pelo usuário.
