import Foundation

/// Recuperação textual determinística da base curricular embarcada.
/// Mantém o prompt pequeno e entrega ao modelo somente os trechos mais relacionados.
enum CurriculumKnowledge {
    private struct Chunk {
        let heading: String
        let text: String
    }

    static func context(subject: String, query: String) -> String {
        guard let url = Bundle.main.url(forResource: "CurriculumKnowledge", withExtension: "md"),
              let source = try? String(contentsOf: url, encoding: .utf8) else {
            return "Base curricular não encontrada no bundle. Sinalize incertezas e não invente fontes."
        }

        let chunks = makeChunks(from: source)
        let terms = tokenize("\(subject) \(query)")
        let ranked = chunks.map { chunk -> (score: Int, chunk: Chunk) in
            let searchable = tokenize("\(chunk.heading) \(chunk.text)")
            let overlap = terms.reduce(0) { total, term in total + (searchable.contains(term) ? 1 : 0) }
            let subjectBoost = chunk.heading.localizedCaseInsensitiveContains(subject) ? 8 : 0
            return (overlap * 2 + subjectBoost, chunk)
        }
        .sorted { lhs, rhs in
            if lhs.score != rhs.score { return lhs.score > rhs.score }
            return lhs.chunk.text.count < rhs.chunk.text.count
        }

        let selected = ranked.filter { $0.score > 0 }.prefix(6).map { $0.chunk.text }
        let fallback = chunks.prefix(3).map { $0.text }
        return String((selected.isEmpty ? fallback : selected).joined(separator: "\n\n").prefix(4500))
    }

    private static func makeChunks(from source: String) -> [Chunk] {
        var chunks: [Chunk] = []
        var heading = "Base curricular"
        var buffer: [String] = []

        func appendChunk() {
            let body = buffer.joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines)
            guard !body.isEmpty else { return }
            chunks.append(Chunk(heading: heading, text: "\(heading)\n\(body)"))
            buffer.removeAll(keepingCapacity: true)
        }

        for line in source.components(separatedBy: .newlines) {
            if line.hasPrefix("## ") || line.hasPrefix("### ") {
                appendChunk()
                heading = String(line.dropFirst(line.hasPrefix("## ") ? 3 : 4))
            } else {
                buffer.append(line)
            }
        }
        appendChunk()
        return chunks
    }

    private static func tokenize(_ text: String) -> Set<String> {
        Set(text.lowercased()
            .split { !$0.isLetter && !$0.isNumber }
            .map(String.init)
            .filter { $0.count > 2 })
    }
}
