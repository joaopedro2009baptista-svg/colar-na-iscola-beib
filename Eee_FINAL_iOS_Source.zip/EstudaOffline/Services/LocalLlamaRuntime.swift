import Foundation
import llama

/// Erros e inferência GGUF executada exclusivamente no dispositivo.
actor LocalLlamaRuntime {
    static let shared = LocalLlamaRuntime()

    private var model: OpaquePointer?
    private var context: OpaquePointer?
    private var vocab: OpaquePointer?
    private var sampler: UnsafeMutablePointer<llama_sampler>?
    private var batch: llama_batch?
    private var isLoaded = false

    func loadModel(at url: URL) throws {
        guard !isLoaded else { return }
        guard FileManager.default.fileExists(atPath: url.path) else {
            throw StudyAIError(message: "O arquivo GGUF não existe no armazenamento do app.")
        }
        let header = Data(try Data(contentsOf: url, options: [.mappedIfSafe]).prefix(4))
        guard header == Data([0x47, 0x47, 0x55, 0x46]) else {
            throw StudyAIError(message: "O arquivo local não tem cabeçalho GGUF válido.")
        }

        llama_backend_init()
        var modelParams = llama_model_default_params()
#if targetEnvironment(simulator)
        modelParams.n_gpu_layers = 0
#endif
        guard let loadedModel = llama_model_load_from_file(url.path, modelParams) else {
            llama_backend_free()
            throw StudyAIError(message: "O llama.cpp não conseguiu abrir o modelo GGUF. Verifique a integridade do arquivo.")
        }

        let threads = max(1, min(8, ProcessInfo.processInfo.processorCount - 2))
        var contextParams = llama_context_default_params()
        contextParams.n_ctx = 4096
        contextParams.n_threads = Int32(threads)
        contextParams.n_threads_batch = Int32(threads)

        guard let loadedContext = llama_init_from_model(loadedModel, contextParams) else {
            llama_model_free(loadedModel)
            llama_backend_free()
            throw StudyAIError(message: "Não foi possível criar o contexto de inferência local.")
        }

        let loadedBatch = llama_batch_init(512, 0, 1)
        let samplerParams = llama_sampler_chain_default_params()
        guard let loadedSampler = llama_sampler_chain_init(samplerParams) else {
            llama_batch_free(loadedBatch)
            llama_free(loadedContext)
            llama_model_free(loadedModel)
            llama_backend_free()
            throw StudyAIError(message: "Não foi possível inicializar o sampler do llama.cpp.")
        }
        llama_sampler_chain_add(loadedSampler, llama_sampler_init_temp(0.25))
        llama_sampler_chain_add(loadedSampler, llama_sampler_init_dist(1234))

        model = loadedModel
        context = loadedContext
        vocab = llama_model_get_vocab(loadedModel)
        batch = loadedBatch
        sampler = loadedSampler
        isLoaded = true
    }

    func unloadModel() {
        sampler.map(llama_sampler_free)
        if var batch { llama_batch_free(batch) }
        if let context { llama_free(context) }
        if let model { llama_model_free(model) }
        sampler = nil
        self.batch = nil
        self.context = nil
        self.model = nil
        vocab = nil
        isLoaded = false
        llama_backend_free()
    }

    func generate(_ prompt: String, maxTokens: Int = 1000) throws -> String {
        guard isLoaded, let context, let vocab, let sampler, var batch else {
            throw StudyAIError(message: "O modelo local ainda não foi carregado. Baixe e carregue o modelo na aba Modelo.")
        }

        let inputTokens = try tokenize(prompt, vocab: vocab, addBOS: true)
        guard !inputTokens.isEmpty else { throw StudyAIError(message: "Não foi possível tokenizar o prompt.") }
        guard inputTokens.count < Int(llama_n_ctx(context)) else {
            throw StudyAIError(message: "O prompt excede o contexto disponível. Reduza o texto da questão.")
        }

        llama_memory_clear(llama_get_memory(context), true)
        clearBatch(&batch)
        for (index, token) in inputTokens.enumerated() {
            addToken(&batch, token, Int32(index), seqIDs: [0], logits: false)
        }
        batch.logits[Int(batch.n_tokens) - 1] = 1
        guard llama_decode(context, batch) == 0 else {
            throw StudyAIError(message: "Falha ao processar o prompt. Tente uma questão menor.")
        }

        var currentPosition = batch.n_tokens
        var output = ""
        var pending: [CChar] = []
        let limit = min(max(1, maxTokens), 2000)

        for _ in 0..<limit {
            try Task.checkCancellation()
            let token = llama_sampler_sample(sampler, context, batch.n_tokens - 1)
            if llama_vocab_is_eog(vocab, token) { break }

            pending.append(contentsOf: tokenPiece(token, vocab: vocab))
            if let valid = String(validatingUTF8: pending + [0]) {
                output += valid
                pending.removeAll(keepingCapacity: true)
            }

            clearBatch(&batch)
            addToken(&batch, token, currentPosition, seqIDs: [0], logits: true)
            guard llama_decode(context, batch) == 0 else {
                throw StudyAIError(message: "A geração foi interrompida pelo llama.cpp.")
            }
            currentPosition += 1
        }

        if !pending.isEmpty { output += String(cString: pending + [0]) }
        return output.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func clearBatch(_ batch: inout llama_batch) {
        batch.n_tokens = 0
    }

    private func addToken(_ batch: inout llama_batch, _ token: llama_token, _ position: llama_pos, seqIDs: [llama_seq_id], logits: Bool) {
        let index = Int(batch.n_tokens)
        batch.token[index] = token
        batch.pos[index] = position
        batch.n_seq_id[index] = Int32(seqIDs.count)
        for (seqIndex, sequenceID) in seqIDs.enumerated() {
            batch.seq_id[index]![seqIndex] = sequenceID
        }
        batch.logits[index] = logits ? 1 : 0
        batch.n_tokens += 1
    }

    private func tokenize(_ text: String, vocab: OpaquePointer, addBOS: Bool) throws -> [llama_token] {
        let utf8Count = text.utf8.count
        let capacity = utf8Count + (addBOS ? 1 : 0) + 1
        let tokens = UnsafeMutablePointer<llama_token>.allocate(capacity: capacity)
        defer { tokens.deallocate() }
        let count = llama_tokenize(vocab, text, Int32(utf8Count), tokens, Int32(capacity), addBOS, false)
        guard count >= 0 else { throw StudyAIError(message: "Falha na tokenização do prompt.") }
        return (0..<Int(count)).map { tokens[$0] }
    }

    private func tokenPiece(_ token: llama_token, vocab: OpaquePointer) -> [CChar] {
        let small = UnsafeMutablePointer<Int8>.allocate(capacity: 8)
        defer { small.deallocate() }
        let count = llama_token_to_piece(vocab, token, small, 8, 0, false)
        if count >= 0 { return Array(UnsafeBufferPointer(start: small, count: Int(count))) }

        let size = Int(-count)
        let large = UnsafeMutablePointer<Int8>.allocate(capacity: size)
        defer { large.deallocate() }
        let actual = llama_token_to_piece(vocab, token, large, Int32(size), 0, false)
        return Array(UnsafeBufferPointer(start: large, count: Int(max(0, actual))))
    }
}
