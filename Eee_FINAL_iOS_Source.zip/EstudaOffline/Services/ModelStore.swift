import Foundation
import SwiftUI
import CryptoKit

@MainActor
final class ModelStore: NSObject, ObservableObject, URLSessionDownloadDelegate {
    static let shared = ModelStore()

    let modelURL = URL(string: "https://huggingface.co/Qwen/Qwen3-4B-GGUF/resolve/main/Qwen3-4B-Q4_K_M.gguf?download=true")!
    let filename = "Qwen3-4B-Q4_K_M.gguf"
    let expectedModelSize: Int64 = 2_497_280_256
    // x-linked-etag oficial do arquivo no endpoint do Hugging Face.
    private let expectedSHA256 = "7485fe6f11af29433bc51cab58009521f205840f5b4ae3a32fa7f92e8534fdf5"

    @Published var progress: Double = 0
    @Published var downloadedBytes: Int64 = 0
    @Published var expectedBytes: Int64 = 2_497_280_256
    @Published var isDownloading = false
    @Published var status = "Modelo ainda não baixado"
    @Published var isReady = false
    @Published var isLoaded = false

    private var downloadTask: URLSessionDownloadTask?
    private var continuation: CheckedContinuation<Void, Error>?
    private var pendingDownloadError: Error?
    private lazy var session: URLSession = {
        URLSession(configuration: .default, delegate: self, delegateQueue: .main)
    }()

    var localURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(filename)
    }

    private var partialURL: URL { localURL.appendingPathExtension("part") }
    private var resumeDataURL: URL { localURL.appendingPathExtension("resume") }

    private override init() {
        super.init()
        refreshStatus()
    }

    func refreshStatus() {
        expectedBytes = expectedModelSize
        if FileManager.default.fileExists(atPath: localURL.path) {
            isReady = true
            status = isLoaded ? "IA local carregada e pronta para uso offline" : "Modelo verificado · pronto para carregar"
        } else if FileManager.default.fileExists(atPath: resumeDataURL.path) {
            isReady = false
            status = "Download interrompido · pode ser retomado"
        } else if FileManager.default.fileExists(atPath: partialURL.path) {
            isReady = false
            status = "Arquivo parcial encontrado · reinicie o download para continuar com segurança"
        } else {
            isReady = false
            status = "Modelo ainda não baixado (aprox. 2,5 GB)"
        }
    }

    func statusDescription() async -> String {
        refreshStatus()
        return status
    }

    func downloadModel() async throws {
        guard !isDownloading else { return }

        if FileManager.default.fileExists(atPath: localURL.path) {
            do {
                try verifyModel(at: localURL)
                isReady = true
                refreshStatus()
                return
            } catch {
                try? FileManager.default.removeItem(at: localURL)
                isReady = false
            }
        }

        try ensureStorageCapacity()
        isDownloading = true
        progress = 0
        downloadedBytes = fileSize(at: partialURL)
        expectedBytes = expectedModelSize
        pendingDownloadError = nil
        status = downloadedBytes > 0 ? "Retomando download…" : "Baixando modelo Qwen3-4B (aprox. 2,5 GB)…"

        defer {
            isDownloading = false
            downloadTask = nil
        }

        do {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                self.continuation = continuation
                let task: URLSessionDownloadTask
                if let resumeData = try? Data(contentsOf: resumeDataURL), !resumeData.isEmpty {
                    task = session.downloadTask(withResumeData: resumeData)
                } else {
                    try? FileManager.default.removeItem(at: resumeDataURL)
                    var request = URLRequest(url: modelURL)
                    request.cachePolicy = .reloadIgnoringLocalCacheData
                    request.httpMethod = "GET"
                    task = session.downloadTask(with: request)
                }
                downloadTask = task
                task.resume()
            }

            try verifyModel(at: partialURL)
            let directory = localURL.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: localURL.path) { try FileManager.default.removeItem(at: localURL) }
            try FileManager.default.moveItem(at: partialURL, to: localURL)
            try? FileManager.default.removeItem(at: resumeDataURL)
            downloadedBytes = expectedModelSize
            expectedBytes = expectedModelSize
            progress = 1
            isReady = true
            status = "Modelo verificado. Carregue-o para iniciar a IA offline."
        } catch {
            if !(error is CancellationError) {
                status = "Download não concluído: \(error.localizedDescription)"
            }
            throw error
        }
    }

    func cancelDownload() {
        guard let task = downloadTask else { return }
        task.cancel(byProducingResumeData: { [weak self] resumeData in
            guard let self else { return }
            if let resumeData, !resumeData.isEmpty {
                try? resumeData.write(to: self.resumeDataURL, options: .atomic)
            }
            self.continuation?.resume(throwing: CancellationError())
            self.continuation = nil
            self.downloadTask = nil
            self.isDownloading = false
            self.status = "Download interrompido · pode ser retomado"
        })
    }

    func deleteModel() throws {
        if isLoaded {
            Task { await LocalLlamaRuntime.shared.unloadModel() }
            isLoaded = false
        }
        for url in [localURL, partialURL, resumeDataURL] where FileManager.default.fileExists(atPath: url.path) {
            try FileManager.default.removeItem(at: url)
        }
        progress = 0
        downloadedBytes = 0
        expectedBytes = expectedModelSize
        refreshStatus()
    }

    func loadModel() async throws {
        refreshStatus()
        guard isReady else { throw StudyAIError(message: "Baixe e valide o modelo antes de carregá-lo.") }
        status = "Carregando modelo na memória…"
        do {
            try await LocalLlamaRuntime.shared.loadModel(at: localURL)
            isLoaded = true
            status = "IA local carregada e pronta para uso offline"
        } catch {
            isLoaded = false
            status = "Falha ao carregar o GGUF: \(error.localizedDescription)"
            throw error
        }
    }

    func unloadModel() async {
        await LocalLlamaRuntime.shared.unloadModel()
        isLoaded = false
        refreshStatus()
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        downloadedBytes = max(0, totalBytesWritten)
        expectedBytes = expectedModelSize
        progress = min(0.999, Double(downloadedBytes) / Double(expectedModelSize))
        status = "Baixando modelo… \(Int(progress * 100))% (\(formatBytes(downloadedBytes)) de \(formatBytes(expectedModelSize)))"
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let response = downloadTask.response as? HTTPURLResponse,
              response.statusCode == 200 || response.statusCode == 206 else {
            pendingDownloadError = ModelStoreError.invalidHTTPStatus((downloadTask.response as? HTTPURLResponse)?.statusCode ?? -1)
            try? FileManager.default.removeItem(at: location)
            try? FileManager.default.removeItem(at: resumeDataURL)
            return
        }

        do {
            let directory = partialURL.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: partialURL.path) { try FileManager.default.removeItem(at: partialURL) }
            try FileManager.default.moveItem(at: location, to: partialURL)
        } catch {
            pendingDownloadError = error
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let continuation else { return }
        self.continuation = nil
        if let pendingDownloadError {
            self.pendingDownloadError = nil
            continuation.resume(throwing: pendingDownloadError)
        } else if let error {
            continuation.resume(throwing: error)
        } else {
            continuation.resume()
        }
    }

    private func ensureStorageCapacity() throws {
        let values = try localURL.deletingLastPathComponent().resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
        let available = values.volumeAvailableCapacityForImportantUsage ?? 0
        let required = expectedModelSize + 512 * 1024 * 1024
        if available > 0 && available < required {
            throw ModelStoreError.insufficientStorage(available: available, required: required)
        }
    }

    private func verifyModel(at url: URL) throws {
        guard FileManager.default.fileExists(atPath: url.path) else { throw ModelStoreError.missingModel }
        let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
        let size = (attributes[.size] as? NSNumber)?.int64Value ?? 0
        guard size == expectedModelSize else { throw ModelStoreError.invalidSize(actual: size, expected: expectedModelSize) }

        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        let magic = handle.readData(ofLength: 4)
        guard magic == Data([0x47, 0x47, 0x55, 0x46]) else { throw ModelStoreError.invalidGGUF }
        try handle.seek(toOffset: 0)
        var hasher = SHA256()
        while true {
            let data = handle.readData(ofLength: 4 * 1024 * 1024)
            if data.isEmpty { break }
            hasher.update(data: data)
        }
        let actual = hasher.finalize().map { String(format: "%02x", $0) }.joined()
        guard actual == expectedSHA256 else { throw ModelStoreError.invalidHash }
    }

    private func fileSize(at url: URL) -> Int64 {
        let attributes = try? FileManager.default.attributesOfItem(atPath: url.path)
        return (attributes?[.size] as? NSNumber)?.int64Value ?? 0
    }

    private func formatBytes(_ bytes: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }
}

private enum ModelStoreError: LocalizedError {
    case invalidHTTPStatus(Int)
    case invalidSize(actual: Int64, expected: Int64)
    case invalidGGUF
    case invalidHash
    case missingModel
    case insufficientStorage(available: Int64, required: Int64)

    var errorDescription: String? {
        switch self {
        case .invalidHTTPStatus(let code): return "O servidor do modelo respondeu HTTP \(code). Nenhum arquivo foi aceito."
        case .invalidSize(let actual, let expected): return "Tamanho inválido do GGUF (\(actual) bytes; esperado \(expected)). O arquivo foi rejeitado."
        case .invalidGGUF: return "O download não é um arquivo GGUF válido. O arquivo foi rejeitado."
        case .invalidHash: return "A verificação SHA-256 do modelo falhou. O arquivo foi rejeitado."
        case .missingModel: return "O arquivo GGUF não existe no armazenamento do app."
        case .insufficientStorage(let available, let required): return "Espaço insuficiente: disponíveis \(available) bytes; necessários pelo menos \(required) bytes."
        }
    }
}
