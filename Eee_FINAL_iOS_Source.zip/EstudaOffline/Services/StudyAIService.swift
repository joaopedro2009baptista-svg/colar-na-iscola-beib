import Foundation

struct StudyAIError: LocalizedError {
    var message: String
    var errorDescription: String? { message }
}

protocol StudyAIService {
    func availabilityDescription() async -> String
    func solveQuestions(recognizedText: String, subject: String) async throws -> [QuestionAnswer]
    func answerChat(_ prompt: String, subject: String) async throws -> String
    func generateEssay(topic: String, instructions: String) async throws -> String
    func reviseEssay(text: String, instructions: String) async throws -> String
}

struct OnDeviceStudyAIService: StudyAIService {
    func availabilityDescription() async -> String {
        await ModelStore.shared.statusDescription()
    }

    private func generate(_ userPrompt: String, subject: String = "Geral", maxTokens: Int = 1200, includeKnowledge: Bool = true) async throws -> String {
        let knowledge = includeKnowledge ? CurriculumKnowledge.context(subject: subject, query: userPrompt) : ""
        let prompt = """
        <|im_start|>system
        Você é o Estuda Offline, tutor do ensino médio brasileiro. Responda em português brasileiro, com rigor conceitual.
        Use o contexto curricular abaixo quando for relevante; ele é apoio, não substitui raciocínio. Se houver informação insuficiente, diga isso. Não invente fatos, fontes, fórmulas ou trechos que não aparecem na questão.
        Para questões objetivas, compare as alternativas antes de escolher. A confiança é uma estimativa subjetiva, nunca garantia.
        CONTEXTO CURRICULAR:
        \(knowledge)
        <|im_end|>
        <|im_start|>user
        \(userPrompt)
        <|im_end|>
        <|im_start|>assistant
        /no_think
        """
        return try await LocalLlamaRuntime.shared.generate(prompt, maxTokens: maxTokens)
    }

    func solveQuestions(recognizedText: String, subject: String) async throws -> [QuestionAnswer] {
        let extractionPrompt = """
        Extraia todas as questões do texto OCR. Retorne somente JSON válido:
        {"questions":[{"number":1,"question":"enunciado","options":{"A":"...","B":"...","C":"...","D":"...","E":"..."}}]}
        Preserve a ordem, não invente texto; marque partes ilegíveis como [ILEGÍVEL]. Texto OCR:
        \(recognizedText)
        """
        let boundedText = String(recognizedText.prefix(24000))
        let extracted = try await generate(extractionPrompt.replacingOccurrences(of: recognizedText, with: boundedText), subject: subject, maxTokens: 700, includeKnowledge: false)
        guard let jsonData = extracted.firstIndex(of: "{").flatMap({ start in
            extracted[start...].lastIndex(of: "}").map { end in Data(extracted[start...end].utf8) }
        }), let envelope = try? JSONDecoder().decode(QuestionEnvelope.self, from: jsonData), !envelope.questions.isEmpty else {
            throw StudyAIError(message: "Não consegui separar as questões do OCR. Confira as fotos e tente novamente.")
        }
        var answers: [QuestionAnswer] = []
        for question in envelope.questions.prefix(30) {
            try Task.checkCancellation()
            let options = ["A","B","C","D","E"].compactMap { key in question.options[key].map { "\(key): \($0)" } }.joined(separator: "\n")
            let prompt = """
            Resolva a questão. Analise cada alternativa e escolha apenas A, B, C, D ou E. Se a imagem/texto não permitir conclusão, use ?. Retorne SOMENTE JSON:
            {"number":\(question.number),"option":"A|B|C|D|E|?","confidence":0,"status":"Respondida|Inconclusiva","interpretedQuestion":"interpretação","rationale":"justificativa curta","uncertainty":"incerteza ou vazio"}
            Enunciado: \(question.question)
            Alternativas:
            \(options)
            """
            let first = try await generate(prompt, subject: subject, maxTokens: 280)
            var result = Self.parseResult(first, number: question.number, fallback: question.question)
            if result.option == "?" || question.question.contains("[ILEGÍVEL]") {
                let secondPrompt = "Faça uma revisão crítica independente. Não invente texto ilegível. Retorne SOMENTE JSON no mesmo formato: {\"number\":\(question.number),\"option\":\"A|B|C|D|E|?\",\"confidence\":0,\"status\":\"Respondida|Inconclusiva\",\"interpretedQuestion\":\"...\",\"rationale\":\"...\",\"uncertainty\":\"...\"}. Primeira análise: \(first)\nQuestão: \(question.question)\nAlternativas:\n\(options)"
                let second = try await generate(secondPrompt, subject: subject, maxTokens: 220)
                let revised = Self.parseResult(second, number: question.number, fallback: question.question)
                if ["A","B","C","D","E","?"].contains(revised.option) { result = revised }
            }
            let option = ["A","B","C","D","E"].contains(result.option.uppercased()) ? result.option.uppercased() : nil
            answers.append(QuestionAnswer(number: question.number, option: option,
                confidencePercent: min(100, max(0, result.confidence)), status: result.status,
                initialInterpretation: Self.parseResult(first, number: question.number, fallback: question.question).interpretedQuestion,
                recognizedQuestion: result.interpretedQuestion,
                rationale: result.rationale + (result.uncertainty.isEmpty ? "" : "\nIncerteza: \(result.uncertainty)")))
        }
        return answers.sorted { $0.number < $1.number }
    }

    func answerChat(_ prompt: String, subject: String) async throws -> String {
        try await generate("Matéria: \(subject)\nExplique a pergunta com clareza, exemplos e passos quando apropriado.\nPergunta: \(prompt)", subject: subject)
    }

    func generateEssay(topic: String, instructions: String) async throws -> String {
        try await generate("Escreva uma redação dissertativo-argumentativa completa em português brasileiro sobre: \(topic). Faça tese clara, dois argumentos desenvolvidos e conclusão coerente. Se for modelo ENEM, inclua proposta de intervenção com agente, ação, meio, finalidade e detalhamento. Evite clichês e dados inventados. Instruções: \(instructions)", subject: "Redação", maxTokens: 1800)
    }

    func reviseEssay(text: String, instructions: String) async throws -> String {
        try await generate("Revise a redação abaixo, preservando a voz do autor. Corrija gramática, coesão, coerência, progressão argumentativa e repertório sem inventar fatos. Entregue a versão revisada e uma lista breve de alterações. Instruções: \(instructions)\nTEXTO:\n\(text)", subject: "Redação", maxTokens: 1800)
    }

    private static func parseResult(_ text: String, number: Int, fallback: String) -> AIQuestionResult {
        if let start = text.firstIndex(of: "{"), let end = text[start...].lastIndex(of: "}"),
           let value = try? JSONDecoder().decode(AIQuestionResult.self, from: Data(text[start...end].utf8)) { return value }
        return AIQuestionResult(number: number, option: "?", confidence: 0, status: "Inconclusiva",
            interpretedQuestion: fallback, rationale: "O modelo não retornou JSON válido.", uncertainty: "Formato inválido; confira a questão.")
    }
}

private struct QuestionEnvelope: Decodable { var questions: [ParsedQuestion] }
