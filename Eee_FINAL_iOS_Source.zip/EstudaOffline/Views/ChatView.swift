import SwiftUI

struct ChatView: View {
    @EnvironmentObject private var store: StudyStore
    @State private var input = ""
    @State private var subject = "Geral"
    @State private var isSending = false
    @State private var errorMessage: String?
    @FocusState private var inputFocused: Bool
    private let ai = OnDeviceStudyAIService()
    private let subjects = ["Geral", "Português/Literatura", "Inglês", "Matemática I", "Matemática II", "Química", "Física", "Biologia", "História", "Geografia", "Filosofia", "Sociologia"]

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("Matéria", selection: $subject) {
                    ForEach(subjects, id: \.self) { Text($0) }
                }.pickerStyle(.menu).padding(.horizontal)

                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 12) {
                        if store.chatMessages.isEmpty {
                            VStack(spacing: 12) {
                                Image(systemName: "bubble.left.and.bubble.right")
                                    .font(.system(size: 40))
                                    .foregroundStyle(.secondary)
                                Text("Tire suas dúvidas").font(.headline)
                                Text("Escolha a matéria e escreva sua pergunta. A resposta usa o modelo local disponível no iPhone.")
                                    .multilineTextAlignment(.center)
                                    .foregroundStyle(.secondary)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 24)
                        }
                        ForEach(store.chatMessages) { message in
                            HStack {
                                if message.isUser { Spacer(minLength: 32) }
                                Text(message.text)
                                    .padding(12)
                                    .background(message.isUser ? Color.mint.opacity(0.22) : Color.white.opacity(0.08),
                                                in: RoundedRectangle(cornerRadius: 14))
                                if !message.isUser { Spacer(minLength: 32) }
                            }
                        }
                    }.padding()
                }
                if let errorMessage {
                    Text(errorMessage).font(.footnote).foregroundStyle(.red).padding(.horizontal)
                }
                HStack(alignment: .bottom, spacing: 8) {
                    TextField("Pergunte sobre a matéria…", text: $input, axis: .vertical)
                        .lineLimit(1...5).textFieldStyle(.roundedBorder)
                        .focused($inputFocused)
                    Button {
                        Task { await send() }
                    } label: {
                        Image(systemName: "arrow.up.circle.fill").font(.title).foregroundStyle(.mint)
                    }.disabled(input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isSending)
                }.padding()
            }
            .navigationTitle("Chat offline")
            .scrollDismissesKeyboard(.interactively)
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Concluído") { inputFocused = false }
                }
            }
        }
    }

    @MainActor
    private func send() async {
        let question = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !question.isEmpty else { return }
        input = ""
        errorMessage = nil
        store.chatMessages.append(ChatMessage(isUser: true, text: question))
        isSending = true
        defer { isSending = false }
        do {
            let response = try await ai.answerChat(question, subject: subject)
            store.chatMessages.append(ChatMessage(isUser: false, text: response))
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
