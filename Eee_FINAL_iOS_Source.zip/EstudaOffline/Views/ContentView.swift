import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            QuestionsView().tabItem { Label("Questões", systemImage: "doc.viewfinder") }
            EssayView().tabItem { Label("Redação", systemImage: "text.alignleft") }
            ChatView().tabItem { Label("Chat", systemImage: "bubble.left.and.bubble.right") }
            SubjectsView().tabItem { Label("Matérias", systemImage: "books.vertical") }
            LogsView().tabItem { Label("Logs", systemImage: "list.bullet.rectangle") }
            ModelManagerView().tabItem { Label("Modelo", systemImage: "cpu") }
        }
        .tint(.mint)
    }
}
