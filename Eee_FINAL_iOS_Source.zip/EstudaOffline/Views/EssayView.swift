import SwiftUI

struct EssayView: View {
    @EnvironmentObject private var store: StudyStore
    @State private var notice: String?
    @State private var isWorking = false
    @State private var revisionInstructions = "Corrija gramática, coesão, coerência e argumentação. Preserve meu estilo natural."
    private let ai = OnDeviceStudyAIService()

    var body: some View {
        NavigationStack {
            Form {
                Section("Tema e instruções") {
                    TextField("Tema da redação", text: $store.essayTopic, axis: .vertical).lineLimit(2...4)
                    TextField("Prompt adicional (opcional)", text: $store.essayInstructions, axis: .vertical).lineLimit(3...6)
                }
                Section("Redação") {
                    TextEditor(text: $store.essayDraft).frame(minHeight: 300)
                    Text("\(store.essayDraft.split { $0.isWhitespace || $0.isNewline }.count) palavras")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("Ações") {
                    Button {
                        Task { await generate() }
                    } label: {
                        Label("Gerar redação completa", systemImage: "sparkles")
                    }.disabled(isWorking || store.essayTopic.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                    Button {
                        Task { await revise() }
                    } label: {
                        Label("Revisar meu texto", systemImage: "pencil.and.outline")
                    }.disabled(isWorking || store.essayDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                    Button("Copiar redação") {
                        UIPasteboard.general.string = store.essayDraft
                        notice = "Texto copiado."
                    }.disabled(store.essayDraft.isEmpty)
                }
                if isWorking { Section { ProgressView("Processando no dispositivo…") } }
                if let notice { Section("Status") { Text(notice).font(.footnote) } }
                Section("Estilo de escrita") {
                    TextField("Instruções de revisão", text: $revisionInstructions, axis: .vertical).lineLimit(2...5)
                    Text("O modelo busca uma escrita natural e específica ao tema, mas não pode garantir que detectores classifiquem um texto de determinada maneira.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Redação")
        }
    }

    @MainActor
    private func generate() async {
        isWorking = true
        notice = nil
        defer { isWorking = false }
        do {
            store.essayDraft = try await ai.generateEssay(topic: store.essayTopic, instructions: store.essayInstructions)
        } catch { notice = error.localizedDescription }
    }

    @MainActor
    private func revise() async {
        isWorking = true
        notice = nil
        defer { isWorking = false }
        do {
            store.essayDraft = try await ai.reviseEssay(text: store.essayDraft, instructions: revisionInstructions)
        } catch { notice = error.localizedDescription }
    }
}
