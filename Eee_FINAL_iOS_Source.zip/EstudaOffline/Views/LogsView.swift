import SwiftUI

struct LogsView: View {
    @EnvironmentObject private var store: StudyStore

    var body: some View {
        NavigationStack {
            Group {
                if store.logs.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "checkmark.circle")
                            .font(.system(size: 42))
                            .foregroundStyle(.secondary)
                        Text("Nenhum log ainda").font(.headline)
                        Text("Questões com leitura incerta ou que precisem de revisão aparecerão aqui.")
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.secondary)
                    }
                    .padding()
                } else {
                    List {
                        ForEach(store.logs) { log in
                            VStack(alignment: .leading, spacing: 7) {
                                HStack {
                                    Text(log.questionNumber == 0 ? "Leitura da imagem" : "Questão \(log.questionNumber)")
                                        .font(.headline)
                                    Spacer()
                                    Text("\(log.confidencePercent)%")
                                        .fontWeight(.semibold)
                                        .foregroundStyle(log.confidencePercent < 50 ? .red : (log.confidencePercent < 70 ? .yellow : .green))
                                }
                                Text("Interpretação inicial: \(log.initialInterpretation)")
                                Text("Após reavaliação: \(log.revisedInterpretation)")
                                Text("Resposta proposta: \(log.proposedAnswer ?? "Indefinida")")
                                Text(log.reason).foregroundStyle(.secondary)
                            }.font(.callout).padding(.vertical, 4)
                        }
                        .onDelete { offsets in store.logs.remove(atOffsets: offsets) }
                    }
                }
            }.navigationTitle("Logs")
        }
    }
}
