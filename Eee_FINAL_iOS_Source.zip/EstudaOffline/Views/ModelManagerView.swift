import SwiftUI

struct ModelManagerView: View {
    @ObservedObject private var models = ModelStore.shared
    @State private var errorMessage: String?
    @State private var isLoading = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Modelo de IA") {
                    Label("Qwen3 4B · Q4_K_M", systemImage: "cpu")
                    Text("Inferência local por llama.cpp. Depois do download e carregamento, perguntas e respostas não são enviadas a servidores.")
                        .font(.footnote).foregroundStyle(.secondary)
                    Text(models.status).font(.callout)
                    if models.expectedBytes > 0 {
                        ProgressView(value: models.progress)
                        Text("\(formatBytes(models.downloadedBytes)) de \(formatBytes(models.expectedBytes))")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }

                Section("Instalação") {
                    Text("O arquivo oficial Qwen3-4B-Q4_K_M.gguf tem aproximadamente 2,5 GB. Reserve espaço adicional para o sistema e para a memória de execução.")
                        .font(.footnote)
                    if models.isDownloading {
                        Button(role: .cancel) { models.cancelDownload() } label: {
                            Label("Cancelar download", systemImage: "xmark.circle")
                        }
                    } else {
                        Button {
                            Task {
                                errorMessage = nil
                                do { try await models.downloadModel() }
                                catch is CancellationError { }
                                catch { errorMessage = error.localizedDescription }
                            }
                        } label: {
                            Label("Baixar ou retomar modelo", systemImage: "arrow.down.circle")
                        }
                        .disabled(models.isReady || isLoading)
                    }

                    Button {
                        Task {
                            isLoading = true
                            errorMessage = nil
                            defer { isLoading = false }
                            do { try await models.loadModel() }
                            catch { errorMessage = error.localizedDescription }
                        }
                    } label: {
                        Label(isLoading ? "Carregando…" : "Carregar IA local", systemImage: "brain")
                    }
                    .disabled(!models.isReady || isLoading || models.isLoaded)

                    if models.isLoaded {
                        Button { Task { await models.unloadModel() } } label: {
                            Label("Descarregar da memória", systemImage: "eject")
                        }
                    }

                    Button(role: .destructive) {
                        do { try models.deleteModel() }
                        catch { errorMessage = error.localizedDescription }
                    } label: {
                        Label("Excluir modelo do iPhone", systemImage: "trash")
                    }
                    .disabled(models.isDownloading || (!models.isReady && !models.isLoaded))
                }

                if let errorMessage { Section("Erro") { Text(errorMessage).foregroundStyle(.red) } }
                Section("Privacidade e limitações") {
                    Text("O OCR usa Vision no dispositivo. Diagramas, gráficos e fórmulas manuscritas podem exigir uma foto melhor e conferência manual.")
                    Text("A confiança exibida é uma estimativa do modelo, não uma taxa de acerto calibrada. O desempenho real deve ser medido com um conjunto de questões e gabaritos.")
                }
            }
            .navigationTitle("Modelo offline")
            .onAppear { models.refreshStatus() }
        }
    }

    private func formatBytes(_ bytes: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }
}
