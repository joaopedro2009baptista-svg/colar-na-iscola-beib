import SwiftUI

struct SubjectsView: View {
    private let subjects: [(String, [String])] = [
        ("Língua Portuguesa / Literatura", ["Parnasianismo", "Simbolismo"]),
        ("Inglês", ["Comparativo", "Superlativo"]),
        ("Matemática I", ["Sistemas lineares"]),
        ("Matemática II", ["Seções e planificações", "Áreas e volumes: cilindro, cone e tronco"]),
        ("Química", ["Gases"]),
        ("Física", ["Óptica geométrica", "Reflexão e refração", "Espelhos esféricos", "Lentes esféricas"]),
        ("Biologia", ["Características gerais das plantas", "Briófitas, pteridófitas, gimnospermas e angiospermas", "Histologia e fisiologia vegetal"]),
        ("História", ["Brasil na Primeira República"]),
        ("Geografia", ["Dinâmica populacional", "População do Brasil"]),
        ("Filosofia", ["Maquiavel e Estado Moderno"]),
        ("Sociologia", ["Mídia e comunicação", "Sociedade e homem-massa"]),
        ("Produção Textual", ["Texto dissertativo-argumentativo"])
    ]

    var body: some View {
        NavigationStack {
            List {
                ForEach(subjects, id: \.0) { subject, topics in
                    Section(subject) {
                        ForEach(topics, id: \.self) { topic in Text(topic) }
                    }
                }
            }.navigationTitle("Matérias")
        }
    }
}
