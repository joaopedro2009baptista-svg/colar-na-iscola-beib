#!/usr/bin/env bash
set -euo pipefail

# Executar na raiz deste projeto em um Mac com Xcode, xcrun e CMake instalado.
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
LLAMA_DIR="${LLAMA_DIR:-$ROOT_DIR/.deps/llama.cpp}"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Este script precisa ser executado no macOS com Xcode instalado." >&2
  exit 2
fi
command -v xcrun >/dev/null || { echo "xcrun não encontrado; instale o Xcode." >&2; exit 2; }
command -v cmake >/dev/null || { echo "cmake não encontrado." >&2; exit 2; }

mkdir -p "$(dirname "$LLAMA_DIR")"
if [[ ! -d "$LLAMA_DIR/.git" ]]; then
  git clone https://github.com/ggml-org/llama.cpp.git "$LLAMA_DIR"
else
  git -C "$LLAMA_DIR" fetch --depth 1 origin master
  git -C "$LLAMA_DIR" reset --hard origin/master
fi

pushd "$LLAMA_DIR" >/dev/null
./build-xcframework.sh ios-sim ios-device
popd >/dev/null

mkdir -p "$ROOT_DIR/Frameworks"
rm -rf "$ROOT_DIR/Frameworks/llama.xcframework"
cp -R "$LLAMA_DIR/build-apple/llama.xcframework" "$ROOT_DIR/Frameworks/llama.xcframework"
printf 'XCFramework criado em %s\n' "$ROOT_DIR/Frameworks/llama.xcframework"
printf 'Commit do llama.cpp: '
git -C "$LLAMA_DIR" rev-parse HEAD
