# Base curricular inicial — Estuda Offline

Esta base é um ponto de partida para recuperação contextual (RAG). Ela não substitui apostilas, livros, aulas nem um conjunto de questões de validação. Acrescente material permitido e alinhado ao programa escolar para ampliar a cobertura.

## Português e Literatura — Parnasianismo e Simbolismo
Parnasianismo: reação ao sentimentalismo romântico; culto da forma, rigor métrico, rimas elaboradas, objetividade, impassibilidade e arte pela arte. No Brasil, Olavo Bilac, Raimundo Correia e Alberto de Oliveira. Simbolismo: musicalidade, sugestão, sinestesia, subjetividade, espiritualidade, mistério, símbolos e imagens vagas; no Brasil, Cruz e Sousa e Alphonsus de Guimaraens. Contraste útil: precisão formal/descrição plástica parnasiana versus sugestão musical e espiritual simbolista.

## Inglês — comparatives and superlatives
Adjetivos curtos: tall–taller–the tallest; adjetivos longos: more interesting–the most interesting. Irregulares: good–better–the best; bad–worse–the worst; far–farther/further–the farthest/furthest. Comparativo normalmente usa than; superlativo usa the. Dobrar consoante final em padrões como big–bigger; y após consoante vira i: happy–happier. Não usar more com -er nem most com -est na forma padrão.

## Matemática I — sistemas lineares
Sistema linear reúne equações com incógnitas comuns. Soluções: única (retas concorrentes), infinitas (equações dependentes/coincidentes) ou nenhuma (retas paralelas incompatíveis). Métodos: substituição, eliminação e escalonamento. Conferir a solução substituindo-a em todas as equações. Para duas equações a1x+b1y=c1 e a2x+b2y=c2, determinante D=a1b2−a2b1; D≠0 implica solução única.

## Matemática II — sólidos, seções, planificações e volumes
Cilindro: V=πr²h; área lateral=2πrh; área total=2πr²+2πrh. Cone: V=πr²h/3; geratriz g=√(r²+h²) no cone reto; área lateral=πrg; total=πr²+πrg. Tronco de cone: V=πh(R²+Rr+r²)/3; área lateral=π(R+r)g. Seções planas dependem da orientação do plano; planificações mostram faces/superfícies sem sobreposição. Usar unidades cúbicas para volume e quadradas para área; manter unidades consistentes.

## Química — gases
Equação dos gases ideais: PV=nRT, com unidades coerentes. Lei de Boyle (T,n constantes): P1V1=P2V2. Charles (P,n constantes): V1/T1=V2/T2. Gay-Lussac (V,n constantes): P1/T1=P2/T2. Lei combinada: P1V1/T1=P2V2/T2 para quantidade fixa. Temperatura em kelvin (K=°C+273,15). Pressão, volume e constante R devem usar unidades compatíveis. Gás ideal é aproximação melhor em baixa pressão e alta temperatura.

## Física — óptica geométrica, reflexão, refração, espelhos e lentes
Reflexão: ângulo de incidência igual ao de reflexão, medidos em relação à normal. Refração: n=c/v; lei de Snell n1 senθ1=n2 senθ2. Ao entrar em meio de maior índice, raio aproxima-se da normal; menor índice, afasta-se. Espelho plano: imagem virtual, direita, mesmo tamanho e simétrica. Equação de Gauss para espelhos/lentes delgadas: 1/f=1/p+1/p'; aumento linear A=i/o=−p'/p em convenção cartesiana comum. Espelho esférico: f=R/2. Lente convergente tem f positivo e pode formar imagem real ou virtual; divergente tem f negativo e, para objeto real, forma imagem virtual, direita e reduzida. Confirmar a convenção de sinais adotada no enunciado.

## Biologia — plantas, grupos vegetais, histologia e fisiologia
Briófitas: avasculares, pequeno porte, gametófito dominante, dependem de água para fecundação; esporófito dependente. Pteridófitas: vasculares sem sementes, esporófito dominante, reprodução por esporos e fecundação dependente de água. Gimnospermas: sementes “nuas”, sem fruto envolvendo-as; pólen reduz dependência da água para fecundação. Angiospermas: flores, frutos e sementes protegidas; dupla fecundação. Tecidos: meristemas (crescimento), epiderme (proteção), parênquima (fotossíntese/reserva), colênquima e esclerênquima (sustentação), xilema (água e sais, em geral fluxo ascendente) e floema (açúcares e outros solutos). Estômatos regulam trocas gasosas/transpiração; xilema relaciona-se à transpiração-coesão-tensão; floema transporta fotoassimilados de fontes a drenos.

## História — Primeira República no Brasil
1889–1930. República da Espada (Deodoro e Floriano) e República Oligárquica. Constituição de 1891: federalismo, presidencialismo e Estado laico. Política dos governadores, coronelismo, voto aberto e fraudes eleitorais sustentaram oligarquias estaduais; política do café com leite é uma simplificação da predominância de elites de São Paulo e Minas. Conflitos e movimentos: Canudos, Revolta da Vacina, Revolta da Chibata, Contestado, greves operárias e tenentismo. Crise de 1929 e tensões políticas contribuíram para a Revolução de 1930 e o fim do período.

## Geografia — dinâmica demográfica e população brasileira
Indicadores: natalidade, mortalidade, fecundidade, expectativa de vida, mortalidade infantil, crescimento vegetativo e saldo migratório. Transição demográfica costuma passar de altas taxas de natalidade/mortalidade a quedas sucessivas e envelhecimento populacional. O Brasil urbanizou-se rapidamente no século XX, reduziu fecundidade e enfrenta envelhecimento. Distribuição desigual relaciona-se à história econômica, urbanização, infraestrutura, clima e oportunidades. Migrações podem ser internas/externas, temporárias/permanentes, voluntárias/forçadas; fatores de expulsão e atração atuam conjuntamente. Cuidado para não confundir crescimento natural com crescimento total, que inclui migração.

## Filosofia — Maquiavel e Estado moderno
Nicolau Maquiavel analisa a política a partir da realidade efetiva e das condições de manutenção do poder, não apenas de ideais morais abstratos. Em O Príncipe, virtù é capacidade política de agir e adaptar-se; fortuna é contingência/sorte. A imagem do governante deve considerar estabilidade e segurança do Estado. Não reduzir a ideia a “os fins justificam os meios”, frase que não é citação literal simples de Maquiavel. Estado moderno: centralização administrativa, monopólio progressivo da força legítima, território, soberania e burocracia; processos históricos variaram por região.

## Sociologia — mídia, comunicação e homem-massa
Meios de comunicação de massa distribuem mensagens a grandes públicos e podem informar, socializar, criar agendas, reforçar estereótipos e influenciar consumo/opinião. Analisar propriedade dos meios, seleção de pautas, enquadramento, algoritmos, publicidade e desigualdade de acesso. “Homem-massa” aparece em críticas à massificação e ao conformismo; contextualizar o autor citado no enunciado, pois a expressão tem usos distintos. Evitar supor que todo público é passivo: recepção envolve repertório, classe, cultura, redes e interpretação crítica.

## Redação dissertativo-argumentativa
Estrutura funcional: introdução com contextualização pertinente e tese; desenvolvimento com argumento, explicação, exemplo/repertório verificável e ligação à tese; conclusão coerente. No ENEM, proposta de intervenção deve conter agente, ação, meio/modo, finalidade/efeito e detalhamento, respeitando direitos humanos. Evitar repertório decorativo, dados inventados, generalizações absolutas, frases prontas e conectivos usados mecanicamente. Priorizar progressão lógica e responder exatamente ao tema.
