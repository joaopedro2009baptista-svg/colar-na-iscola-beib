import Foundation

enum CurriculumKnowledge {
    static func context(subject: String, query: String) -> String {
        let url = Bundle.main.url(forResource: "CurriculumKnowledge", withExtension: "md")
        let text = url.flatMap { try? String(contentsOf: $0, encoding: .utf8) } ?? "Base curricular não encontrada no bundle. Responda com o conhecimento do modelo e sinalize incertezas."
        let terms = Set((subject + " " + query).lowercased().split { !$0.isLetter && !$0.isNumber }.map(String.init).filter { $0.count > 3 })
        let sections = text.components(separatedBy: "\n## ")
        let ranked = sections.map { section -> (Int, String) in
            let lower = section.lowercased()
            let score = terms.reduce(0) { $0 + (lower.contains($1) ? 1 : 0) }
            return (score, section)
        }.sorted { $0.0 > $1.0 }
        let chosen = ranked.filter { $0.0 > 0 }.prefix(4).map { $0.1 }
        return (chosen.isEmpty ? Array(sections.prefix(3)) : chosen).joined(separator: "\n\n").prefix(7000).description
    }
}
