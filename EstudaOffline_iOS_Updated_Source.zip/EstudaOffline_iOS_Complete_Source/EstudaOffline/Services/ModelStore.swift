import Foundation
import SwiftUI
import CryptoKit

@MainActor
final class ModelStore: NSObject, ObservableObject, URLSessionDownloadDelegate {
    static let shared = ModelStore()

    let modelURL = URL(string: "https://huggingface.co/Qwen/Qwen3-4B-GGUF/resolve/main/Qwen3-4B-Q4_K_M.gguf?download=true")!
    let filename = "Qwen3-4B-Q4_K_M.gguf"
    // SHA-256 publicado pela página oficial do arquivo no Hugging Face.
    private let expectedSHA256 = "7485fe6f11af29433bc51cab58009521f205840f5b4ae3a32fa7f92e8534fdf5"

    @Published var progress: Double = 0
    @Published var downloadedBytes: Int64 = 0
    @Published var expectedBytes: Int64 = 0
    @Published var isDownloading = false
    @Published var status = "Modelo ainda não baixado"
    @Published var isReady = false
    @Published var isLoaded = false

    private var downloadTask: URLSessionDownloadTask?
    private var continuation: CheckedContinuation<Void, Error>?
    private lazy var session: URLSession = {
        URLSession(configuration: .default, delegate: self, delegateQueue: .main)
    }()

    var localURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(filename)
    }

    private var resumeDataURL: URL { localURL.appendingPathExtension("resume") }

    private override init() {
        super.init()
        refreshStatus()
    }

    func refreshStatus() {
        if FileManager.default.fileExists(atPath: localURL.path) {
            isReady = true
            status = isLoaded ? "IA local carregada e pronta para uso offline" : "Modelo verificado · pronto para carregar"
        } else if FileManager.default.fileExists(atPath: resumeDataURL.path) {
            isReady = false
            status = "Download interrompido · pode ser retomado"
        } else {
            isReady = false
            status = "Modelo ainda não baixado (aprox. 2,5 GB)"
        }
    }

    func statusDescription() async -> String {
        refreshStatus()
        return status
    }

    func downloadModel() async throws {
        guard !isDownloading else { return }
        if FileManager.default.fileExists(atPath: localURL.path) {
            try verifyModel(at: localURL)
            refreshStatus()
            return
        }

        isDownloading = true
        progress = 0
        downloadedBytes = 0
        expectedBytes = 0
        status = downloadedBytes > 0 ? "Retomando download…" : "Baixando modelo de aproximadamente 2,5 GB…"

        defer {
            isDownloading = false
            downloadTask = nil
        }

        do {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                self.continuation = continuation
                let task: URLSessionDownloadTask
                if let resumeData = try? Data(contentsOf: self.resumeDataURL) {
                    task = self.session.downloadTask(withResumeData: resumeData)
                } else {
                    var request = URLRequest(url: self.modelURL)
                    request.cachePolicy = .reloadIgnoringLocalCacheData
                    task = self.session.downloadTask(with: request)
                }
                downloadTask = task
                task.resume()
            }
            try verifyModel(at: localURL)
            isReady = true
            progress = 1
            status = "Modelo verificado. Carregue-o para iniciar a IA offline."
        } catch {
            if !(error is CancellationError) { status = "Download incompleto: \(error.localizedDescription)" }
            throw error
        }
    }

    func cancelDownload() {
        guard let task = downloadTask else { return }
        task.cancel(byProducingResumeData: { [weak self] resumeData in
            guard let self else { return }
            if let resumeData {
                try? resumeData.write(to: self.resumeDataURL, options: .atomic)
            }
            self.continuation?.resume(throwing: CancellationError())
            self.continuation = nil
            self.downloadTask = nil
            self.isDownloading = false
            self.refreshStatus()
        })
    }

    func deleteModel() throws {
        if isLoaded {
            Task { await LocalLlamaRuntime.shared.unloadModel() }
            isLoaded = false
        }
        if FileManager.default.fileExists(atPath: localURL.path) { try FileManager.default.removeItem(at: localURL) }
        if FileManager.default.fileExists(atPath: resumeDataURL.path) { try FileManager.default.removeItem(at: resumeDataURL) }
        progress = 0
        downloadedBytes = 0
        expectedBytes = 0
        refreshStatus()
    }

    func loadModel() async throws {
        refreshStatus()
        guard isReady else { throw StudyAIError(message: "Baixe e verifique o modelo primeiro.") }
        status = "Carregando modelo na memória…"
        try await LocalLlamaRuntime.shared.loadModel(at: localURL)
        isLoaded = true
        status = "IA local carregada e pronta para uso offline"
    }

    func unloadModel() async {
        await LocalLlamaRuntime.shared.unloadModel()
        isLoaded = false
        refreshStatus()
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        downloadedBytes = totalBytesWritten
        expectedBytes = totalBytesExpectedToWrite
        if totalBytesExpectedToWrite > 0 { progress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite) }
        status = "Baixando modelo… \(Int(progress * 100))%"
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        do {
            let directory = localURL.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: localURL.path) { try FileManager.default.removeItem(at: localURL) }
            try FileManager.default.moveItem(at: location, to: localURL)
            if FileManager.default.fileExists(atPath: resumeDataURL.path) { try FileManager.default.removeItem(at: resumeDataURL) }
        } catch {
            continuation?.resume(throwing: error)
            continuation = nil
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let continuation else { return }
        self.continuation = nil
        if let error { continuation.resume(throwing: error) }
        else { continuation.resume() }
    }

    private func verifyModel(at url: URL) throws {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var hasher = SHA256()
        while autoreleasepool(invoking: {
            let data = handle.readData(ofLength: 1024 * 1024)
            guard !data.isEmpty else { return false }
            hasher.update(data: data)
            return true
        }) {}
        let actual = hasher.finalize().map { String(format: "%02x", $0) }.joined()
        guard actual == expectedSHA256 else {
            try? FileManager.default.removeItem(at: url)
            throw StudyAIError(message: "A verificação SHA-256 falhou; o modelo foi removido por segurança.")
        }
    }
}
