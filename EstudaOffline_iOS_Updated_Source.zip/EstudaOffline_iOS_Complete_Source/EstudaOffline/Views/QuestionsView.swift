import SwiftUI
import PhotosUI

struct QuestionsView: View {
    @EnvironmentObject private var store: StudyStore
    @State private var selectedPhotos: [PhotosPickerItem] = []
    @State private var isReading = false
    @State private var isSolving = false
    @State private var errorMessage: String?
    @State private var selectedSubject = "Geral"
    private let ocr = LocalOCRService()
    private let ai = OnDeviceStudyAIService()
    private let subjects = ["Geral", "Português/Literatura", "Inglês", "Matemática I", "Matemática II", "Química", "Física", "Biologia", "História", "Geografia", "Filosofia", "Sociologia"]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Resolutor de provas").font(.largeTitle.bold())
                    Text("Selecione uma ou mais fotos. O OCR e o modelo compatível são executados no dispositivo.")
                        .foregroundStyle(.secondary)

                    Picker("Matéria", selection: $selectedSubject) {
                        ForEach(subjects, id: \.self) { Text($0) }
                    }
                    .pickerStyle(.menu)

                    PhotosPicker(selection: $selectedPhotos, maxSelectionCount: 12, matching: .images) {
                        Label("Selecionar páginas da prova", systemImage: "photo.stack")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)

                    if isReading || isSolving {
                        ProgressView(isReading ? "Lendo imagens…" : "Resolvendo e reavaliando questões…")
                    }
                    if let errorMessage {
                        Text(errorMessage).foregroundStyle(.red).font(.callout)
                    }
                    if !store.recognizedText.isEmpty {
                        DisclosureGroup("Texto reconhecido (\(store.recognizedText.count) caracteres)") {
                            Text(store.recognizedText)
                                .font(.footnote)
                                .textSelection(.enabled)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.top, 8)
                        }
                        .padding()
                        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 14))

                        Button {
                            Task { await solve() }
                        } label: {
                            Label("Resolver todas as questões", systemImage: "sparkles")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(isSolving)
                    }

                    if !store.answers.isEmpty {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text("Respostas").font(.title2.bold())
                                Spacer()
                                Button("Copiar lista") {
                                    UIPasteboard.general.string = store.answers.map { "\($0.number)-\($0.option ?? "?")" }.joined(separator: "\n")
                                }
                            }
                            Text(store.answers.map { "\($0.number)-\($0.option ?? "?")" }.joined(separator: "   "))
                                .font(.system(.body, design: .monospaced).bold())
                                .textSelection(.enabled)
                            ForEach(store.answers) { answer in AnswerRow(answer: answer) }
                        }
                    }
                }
                .padding()
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Limpar") {
                        store.clearQuestionSession()
                        selectedPhotos = []
                        errorMessage = nil
                    }
                }
            }
            .onChange(of: selectedPhotos) { _, items in
                guard !items.isEmpty else { return }
                Task { await read(items) }
            }
        }
    }

    @MainActor
    private func read(_ items: [PhotosPickerItem]) async {
        isReading = true
        errorMessage = nil
        store.recognizedText = ""
        store.answers = []
        defer { isReading = false }
        var allText: [String] = []
        for (index, item) in items.enumerated() {
            do {
                guard let data = try await item.loadTransferable(type: Data.self),
                      let image = UIImage(data: data) else { continue }
                let text = try await ocr.recognizeText(in: image)
                allText.append("\n--- PÁGINA \(index + 1) ---\n\(text)")
                if text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    store.addLog(QuestionLog(questionNumber: 0,
                        initialInterpretation: "Nenhum texto reconhecido na página \(index + 1)",
                        revisedInterpretation: "Solicitar nova foto, com foco e iluminação melhores",
                        proposedAnswer: nil, confidencePercent: 0,
                        reason: "OCR não encontrou texto legível."))
                }
            } catch {
                errorMessage = "Erro ao ler uma das imagens: \(error.localizedDescription)"
            }
        }
        store.recognizedText = allText.joined(separator: "\n")
        if store.recognizedText.isEmpty {
            errorMessage = "Não foi possível reconhecer texto. Tente uma foto mais nítida."
        }
    }

    @MainActor
    private func solve() async {
        guard !store.recognizedText.isEmpty else { return }
        isSolving = true
        errorMessage = nil
        defer { isSolving = false }
        do {
            let answers = try await ai.solveQuestions(recognizedText: store.recognizedText, subject: selectedSubject)
            store.answers = answers
            for answer in answers where answer.confidencePercent < 70 || answer.option == nil || answer.status.localizedCaseInsensitiveContains("inconclusiva") {
                store.addLog(QuestionLog(
                    questionNumber: answer.number,
                    initialInterpretation: answer.initialInterpretation,
                    revisedInterpretation: answer.recognizedQuestion,
                    proposedAnswer: answer.option,
                    confidencePercent: answer.confidencePercent,
                    reason: answer.rationale
                ))
            }
            if answers.isEmpty { errorMessage = "Nenhuma questão identificada." }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

struct AnswerRow: View {
    let answer: QuestionAnswer
    private var color: Color {
        if answer.confidencePercent < 50 { .red }
        else if answer.confidencePercent < 70 { .yellow }
        else { .green }
    }
    var body: some View {
        HStack(spacing: 10) {
            Text("\(answer.number)-\(answer.option ?? "?")")
                .font(.headline.monospaced())
                .frame(width: 70, alignment: .leading)
            VStack(alignment: .leading, spacing: 5) {
                HStack {
                    Text(answer.status).font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    Text("\(answer.confidencePercent)%").font(.caption.bold()).foregroundStyle(color)
                }
                ProgressView(value: Double(answer.confidencePercent), total: 100).tint(color)
            }
        }
        .padding(12)
        .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 10))
    }
}
