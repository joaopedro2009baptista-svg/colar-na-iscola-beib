# Estuda Offline — projeto iOS com LLM local

Esta fonte implementa um app SwiftUI para iPhone que executa OCR e inferência de texto localmente. O caminho de IA usa `llama.cpp` e um arquivo GGUF baixado explicitamente pelo usuário; não usa Apple Intelligence, Foundation Models, ChatGPT ou API de inferência externa.

## Estado verificado nesta entrega

A fonte inclui fluxo de seleção de fotos, OCR local com Vision, extração de questões A–E, segunda avaliação de itens de baixa confiança, logs locais, chat por matéria, geração/revisão de redação, recuperação textual da base curricular e gerenciamento do modelo. O runtime foi alinhado ao exemplo Swift oficial atual do llama.cpp, incluindo liberação de batch, sampler, contexto, modelo e backend.

O projeto **não foi compilado neste ambiente**: o ambiente disponível é Linux e não possui Xcode, SDK iOS ou certificados Apple. Portanto, não há IPA nesta entrega e nenhuma afirmação de funcionamento em iPhone ou modo avião foi feita sem o teste correspondente.

## Modelo e integridade

O candidato inicial é `Qwen3-4B-Q4_K_M.gguf`, publicado no repositório oficial [`Qwen/Qwen3-4B-GGUF`](https://huggingface.co/Qwen/Qwen3-4B-GGUF). A página informa licença Apache-2.0, tamanho aproximado de 2,5 GB e SHA-256 do arquivo `7485fe6f11af29433bc51cab58009521f205840f5b4ae3a32fa7f92e8534fdf5`. O app verifica esse hash antes de marcar o modelo como pronto.

O download usa `URLSessionDownloadTask`, mostra progresso, permite cancelar, tenta retomar por `resumeData`, salva no Application Support e oferece exclusão e descarregamento da memória. A URL e o hash ficam em `EstudaOffline/Services/ModelStore.swift`; confirme-os novamente antes de uma distribuição comercial.

Depois de carregar o modelo, ative o modo avião e repita chat, resolução e redação. O app deve ser considerado offline somente depois desse teste em um aparelho real.

## Compilar o llama.cpp e integrar no Xcode

Em um Mac com Xcode, `xcrun`, CMake e Git:

```bash
cd EstudaOffline_iOS_Complete_Source
./scripts/prepare_llama_xcframework.sh
```

O script clona a fonte oficial do llama.cpp, executa `build-xcframework.sh ios-sim ios-device` e coloca `Frameworks/llama.xcframework` no projeto. No Xcode, adicione esse XCFramework ao target `EstudaOffline` em **Frameworks, Libraries, and Embedded Content**. O projeto já referencia `import llama`; a presença do módulo depende do XCFramework efetivamente gerado.

O script oficial do llama.cpp documenta iOS 16.4 como mínimo para o build do XCFramework. O projeto foi ajustado para deployment target 16.4. O iPhone 15 Pro Max é um alvo de dispositivo compatível, mas memória, latência e estabilidade ainda precisam ser medidas no aparelho.

## Build, testes e IPA

1. Abra `EstudaOffline.xcodeproj` no Xcode.
2. Adicione o time de desenvolvimento e um Bundle ID exclusivo.
3. Compile primeiro para um iPhone real, não apenas para o simulador.
4. Baixe o GGUF, valide o hash e carregue a IA local.
5. Teste OCR, questão objetiva, segunda avaliação, chat, redação, descarregamento e reinício.
6. Repita os fluxos em modo avião.
7. Só depois faça Archive e exporte a IPA com certificado e perfil de provisionamento autorizados.

Uma IPA não assinada ou assinada com perfil incompatível não é garantidamente instalável pelo ESign. O método de assinatura e a validade dependem do certificado, do provisioning profile, do Bundle ID e do dispositivo.

## Limitações conhecidas

A base curricular embarcada é inicial e não representa cobertura validada de 90%. A confiança é uma estimativa declarada pelo modelo, não uma probabilidade calibrada. OCR textual pode falhar em gráficos, diagramas, fórmulas manuscritas e imagens ilegíveis. A precisão por disciplina, latência, memória e qualidade da redação ainda exigem benchmark separado com questões e gabaritos verificados.

## Referências oficiais

- llama.cpp: https://github.com/ggml-org/llama.cpp
- Documentação do XCFramework: https://github.com/ggml-org/llama.cpp/blob/master/docs/xcframework.md
- Exemplo SwiftUI oficial: https://github.com/ggml-org/llama.cpp/tree/master/examples/llama.swiftui
- Modelo Qwen3-4B-GGUF: https://huggingface.co/Qwen/Qwen3-4B-GGUF
- Arquivo GGUF e SHA-256: https://huggingface.co/Qwen/Qwen3-4B-GGUF/blob/main/Qwen3-4B-Q4_K_M.gguf
